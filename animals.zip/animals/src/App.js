import './App.css';
import { useState } from "react";
import ShowAnimals from "./ShowAnimals";


function randomAnimlas(){
  const animals = ['horse', 'cat', 'dog', 'cow', 'bird'];
  
  //console.log(Math.random());
  //console.log(animals.length);
  //console.log(Math.random()*animals.length);
  //console.log(Math.floor(Math.random()*animals.length));

  return animals[Math.floor(Math.random()*animals.length)];
}

const App = () => {

  const [animals, setAnimals] = useState([]);

  const handleClick = () => {
    setAnimals([...animals,randomAnimlas()]);
  }

  const renderedAnimals = animals.map((animal,index) => {
    return <ShowAnimals type={animal} key={index} />;
  })
  return(
    <div className="app">
      <button onClick={handleClick}>Add Animals</button>
      <div className="animal-list">{renderedAnimals}</div>
    </div>
  )
}

export default App;
